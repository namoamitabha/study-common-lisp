﻿using System;

namespace monotest
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			//MyClass test = new MyClass ();

			Console.WriteLine("Hello {0}", "World");
		}
	}
}

